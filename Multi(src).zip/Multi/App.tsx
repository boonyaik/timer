import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { TIMER_STAGES } from './constants';
import type { TimerStage } from './types';
import { PlayIcon, PauseIcon, ResetIcon, VolumeOnIcon, VolumeOffIcon } from './components/icons';

const formatTime = (timeInSeconds: number) => {
  const minutes = Math.floor(timeInSeconds / 60);
  const seconds = timeInSeconds % 60;
  return {
    minutes: String(minutes).padStart(2, '0'),
    seconds: String(seconds).padStart(2, '0'),
  };
};

// Placeholder beep sound encoded in Base64
const BEEP_AUDIO_SRC = "audio/audio.mp3";

const App: React.FC = () => {
  const [currentTimerIndex, setCurrentTimerIndex] = useState<number>(0);
  const [time, setTime] = useState<number>(TIMER_STAGES[0].duration);
  const [isPaused, setIsPaused] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const wakeLockRef = useRef<any | null>(null); // WakeLockSentinel
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentStage = useMemo(() => TIMER_STAGES[currentTimerIndex], [currentTimerIndex]);
  const initialDuration = currentStage.duration;
  const isFinished = time < 0 && currentTimerIndex >= TIMER_STAGES.length - 1;

  // --- Screen Wake Lock Logic ---
  useEffect(() => {
    const isTimerActive = !isPaused && !isFinished;

    const acquireWakeLock = async () => {
      if ('wakeLock' in navigator) {
        try {
          wakeLockRef.current = await navigator.wakeLock.request('screen');
          console.log('Screen Wake Lock acquired.');
          wakeLockRef.current.addEventListener('release', () => {
            console.log('Screen Wake Lock was released by the browser.');
            wakeLockRef.current = null;
          });
        } catch (err: any) {
          console.error(`Could not acquire wake lock: ${err.name}, ${err.message}`);
        }
      } else {
        console.warn('Screen Wake Lock API not supported.');
      }
    };

    const releaseWakeLock = async () => {
      if (wakeLockRef.current) {
        await wakeLockRef.current.release();
        wakeLockRef.current = null;
        console.log('Screen Wake Lock released.');
      }
    };

    if (isTimerActive) {
      acquireWakeLock();
    } else {
      releaseWakeLock();
    }

    return () => {
      releaseWakeLock();
    };
  }, [isPaused, isFinished]);
  
  // Handle re-acquiring the lock on tab visibility change
  useEffect(() => {
    const handleVisibilityChange = async () => {
      const isTimerActive = !isPaused && !isFinished;
      if (document.visibilityState === 'visible' && isTimerActive && !wakeLockRef.current) {
        console.log('Tab is visible again, re-acquiring wake lock...');
        if ('wakeLock' in navigator) {
            try {
              wakeLockRef.current = await navigator.wakeLock.request('screen');
               wakeLockRef.current.addEventListener('release', () => {
                console.log('Screen Wake Lock was released by the browser.');
                wakeLockRef.current = null;
              });
            } catch (err: any) {
                 console.error(`Could not re-acquire wake lock: ${err.name}, ${err.message}`);
            }
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isPaused, isFinished]);


  // --- Timer Logic ---
  useEffect(() => {
    if (isPaused || time < 0) return;

    const interval = setInterval(() => {
      setTime(prevTime => prevTime - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isPaused, time]);

  useEffect(() => {
    if (time < 0) {
      if (audioRef.current && !isMuted) {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(error => console.error("Audio play failed", error));
      }
      if (currentTimerIndex < TIMER_STAGES.length - 1) {
        const nextIndex = currentTimerIndex + 1;
        setCurrentTimerIndex(nextIndex);
        setTime(TIMER_STAGES[nextIndex].duration);
      } else {
        setIsPaused(true);
      }
    }
  }, [time, currentTimerIndex, isMuted]);

  const handleStageSelect = useCallback((index: number) => {
    setCurrentTimerIndex(index);
    setTime(TIMER_STAGES[index].duration);
    setIsPaused(true);
  }, []);
  
  const handleMuteToggle = () => {
    setIsMuted(prev => !prev);
  };

  const handlePrimaryClick = useCallback(() => {
    if (isFinished) {
      handleStageSelect(0);
    } else {
      setIsPaused(prev => !prev);
    }
  }, [isFinished, handleStageSelect]);

  const handleResetClick = useCallback(() => {
    setTime(initialDuration);
    setIsPaused(true);
  }, [initialDuration]);

  const { minutes, seconds } = formatTime(time < 0 ? 0 : time);
  const progress = useMemo(() => (initialDuration - time) / initialDuration, [time, initialDuration]);
  const isPristine = time === initialDuration;

  let primaryButtonContent;
  if (isFinished) {
    primaryButtonContent = (
      <>
        <ResetIcon className="w-6 h-6 mr-2" />
        Start Over
      </>
    );
  } else if (isPaused) {
    primaryButtonContent = (
      <>
        <PlayIcon className="w-6 h-6 mr-2" />
        {isPristine ? 'Start' : 'Resume'}
      </>
    );
  } else {
    primaryButtonContent = (
      <>
        <PauseIcon className="w-6 h-6 mr-2" />
        Pause
      </>
    );
  }

  return (
    <main className="bg-gray-900 text-white min-h-screen flex flex-col items-center justify-center p-4 font-sans antialiased overflow-hidden">
      <audio ref={audioRef} src={BEEP_AUDIO_SRC} preload="auto" />
      <div className="w-full max-w-4xl mx-auto flex flex-col items-center text-center">
        
        <div className="landscape:hidden">
          <h1 className="text-4xl font-bold text-indigo-400 mb-2">Okiyome Timer</h1>
          <p className="text-lg text-gray-400 mb-8">Select a stage or press start to begin.</p>
        </div>

        <div className="relative w-72 h-72 sm:w-80 sm:h-80 landscape:w-[45vh] landscape:h-[45vh] flex items-center justify-center mb-4 landscape:mb-2">
            <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                <circle cx="60" cy="60" r="54" fill="none" stroke="rgba(255, 255, 255, 0.1)" strokeWidth="12" />
                <circle
                    cx="60"
                    cy="60"
                    r="54"
                    fill="none"
                    stroke="currentColor"
                    className="text-indigo-300"
                    strokeWidth="12"
                    strokeDasharray={Math.PI * 108}
                    strokeDashoffset={(1 - progress) * Math.PI * 108}
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dashoffset 1s linear' }}
                />
            </svg>
            <div className="z-10 flex flex-col items-center">
                 <p className="text-xl sm:text-2xl landscape:text-[5vh] font-semibold text-gray-400 mb-1 capitalize">
                    Point: <span className="text-indigo-400">{currentStage.label}</span>
                </p>
                <div className="font-mono text-7xl sm:text-8xl landscape:text-[35vh] font-bold tracking-tighter">
                    <span>{minutes}</span>
                    <span className={isPaused ? "" : "animate-pulse"}>:</span>
                    <span>{seconds}</span>
                </div>
            </div>
        </div>

        <div className="flex space-x-4 mb-6 landscape:mb-4">
          <button
            onClick={handlePrimaryClick}
            className={`flex items-center justify-center px-8 py-4 rounded-full text-xl font-bold transition-all duration-200 ease-in-out shadow-lg transform hover:scale-105 ${
              isPaused ? 'bg-indigo-600 hover:bg-indigo-500' : 'bg-yellow-500 hover:bg-yellow-400 text-gray-900'
            }`}
          >
            {primaryButtonContent}
          </button>
          <button
            onClick={handleResetClick}
            disabled={isPristine && isPaused}
            className="flex items-center justify-center p-4 rounded-full text-xl font-bold bg-gray-700 hover:bg-gray-600 text-white transition-all duration-200 ease-in-out shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100 transform enabled:hover:scale-105"
            aria-label="Reset Timer"
          >
            <ResetIcon className="w-6 h-6" />
          </button>
          <button
            onClick={handleMuteToggle}
            className="flex items-center justify-center p-4 rounded-full text-xl font-bold bg-gray-700 hover:bg-gray-600 text-white transition-all duration-200 ease-in-out shadow-lg transform hover:scale-105"
            aria-label={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeOffIcon className="w-6 h-6" /> : <VolumeOnIcon className="w-6 h-6" />}
          </button>
        </div>
        
        <div className="w-full">
            <h2 className="text-lg font-semibold text-gray-300 mb-4 landscape:hidden">Stages</h2>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
            {TIMER_STAGES.map((stage, index) => (
                <button
                key={`${stage.label}-${index}`}
                onClick={() => handleStageSelect(index)}
                className={`px-3 py-2 sm:py-4 rounded-lg font-mono font-bold text-xs sm:text-sm transition-colors duration-200 ${
                    currentTimerIndex === index
                    ? 'bg-indigo-500 text-white ring-2 ring-indigo-300'
                    : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                }`}
                >
                {stage.label}
                </button>
            ))}
            </div>
        </div>
      </div>
    </main>
  );
};

export default App;
