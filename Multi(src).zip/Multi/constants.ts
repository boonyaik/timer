import type { TimerStage } from './types';

export const TIMER_STAGES: TimerStage[] = [
  { label: '8(Forehead)', duration: 10 * 60 },
  { label: '7(Left)', duration: 3 * 60 },
  { label: '7+(Left)', duration: 3 * 60 },
  { label: '7(Right)', duration: 3 * 60 },
  { label: '7+(Right)', duration: 3 * 60 },
  { label: '6(Left)', duration: 3 * 60 },
  { label: '6(Right)', duration: 3 * 60 },
  { label: '1(Left)', duration: 5 * 60 },
  { label: '1(Right)', duration: 5 * 60 },
  { label: 'Extra 1', duration: 3 * 60 },
  { label: 'Extra 2', duration: 3 * 60 },
  { label: 'Extra 3', duration: 3 * 60 },
  { label: 'Extra 4', duration: 3 * 60 },
];
