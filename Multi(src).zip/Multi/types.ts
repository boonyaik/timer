export interface TimerStage {
  label: string;
  duration: number; // in seconds
}
